<?php 
 require('conector.php');

 	$con= new conectorBD;


 	echo $con->userSession();



 ?>